# Consts
## Directions
NONE = 0
UP = 1
LEFT = 2
DIAGONAL = 3

## Points
GAP_PENALTY = -2
MATCH_BONUS = 2
MISMATCH_PENALTY = -1